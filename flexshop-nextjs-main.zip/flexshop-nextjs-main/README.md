# Welcome to Flexshop

Flexshop is a platform for manage Product

# Start

- npm install (for install all depedencies)
- npm run server (for start json server database)
- npm run profile (for start json server account database)
- npm run dev (for running the app)
